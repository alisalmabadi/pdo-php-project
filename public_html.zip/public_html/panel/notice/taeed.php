

<span class="label label-primary">
<?php
										echo "تایید شده";
									 ?>
</span>