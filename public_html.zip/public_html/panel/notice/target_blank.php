

<span class="label label-primary">
<?php
										echo "در صفحه دیگر";
									 ?>
</span>