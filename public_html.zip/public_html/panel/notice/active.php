<span class="label label-success">
<?php
										echo "فعال";
									 ?>
</span>