
									 <div class="col-lg-12">
									
									<div class="alert alert-success alert-block fade in">
                                    <button data-dismiss="alert" class="close close-sm" type="button">
                                        <i class="icon-remove"></i>
                                    </button>
                                    <h4 style="font-family: yekan,'Open Sans', sans-serif;">
                                        <i class="icon-ok-sign"></i>
										
                                    عملیات موفق آمیز بود!
									 
                                  </h4>
                                    <p>
									<?php
									
									echo $success;
									?>
									
									
									
									</p>
                                </div>
								
								</div>