

<span class="label label-warning">
<?php
										echo "غیرمجاز";
									 ?>
</span>