	    <div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                                <h4 class="modal-title">هشدار!</h4>
                                            </div>
                                            <div class="modal-body">
                                          آیا واقعا مایل به حذف این لینک هستید؟
                                         
                                            </div>
                                            <div class="modal-footer">
                                                <button data-dismiss="modal" class="btn btn-default" type="button">بستن</button>
                                                <a href="?del_id=<?php echo $idha; ?>"><button class="btn btn-warning" type="button">بله حذف کن</button></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>