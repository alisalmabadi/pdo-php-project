<span class="label label-danger">
									<?php
								
										echo "غیر فعال";
									
									 ?>
									 </span>