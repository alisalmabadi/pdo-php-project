
<span class="label label-inverse">
<?php
										echo "در صفحه جاری";
									 ?>
</span>