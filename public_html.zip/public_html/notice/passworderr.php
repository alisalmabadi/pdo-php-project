						
<div class="alert">
  <span class="closebtn">&times;</span>  
  <strong>خطا!</strong>    
                                            <?php
									
									
											echo $passworderr;
									
									?>
</div>



									


								